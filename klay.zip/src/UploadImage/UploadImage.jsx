import styles from "./UploadImage.module.css";
import { useState, useRef, useEffect } from "react";

function UploadImage() {
  const [image, setImage] = useState(null);
  const [liked, setLiked] = useState(false);
  const fileInputRef = useRef(null);

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith("image/")) {
      setImage(Object.assign(file, { preview: URL.createObjectURL(file) }));
    } else {
      alert("Please upload a valid image file (JPEG, PNG, etc.).");
    }
  };

  const toggleLike = () => {
    setLiked(!liked);
  };

  // Cleanup the object URL when component unmounts or image changes
  useEffect(() => {
    return () => {
      if (image) {
        URL.revokeObjectURL(image.preview);
      }
    };
  }, [image]);

  return (
    <div>
      <div className={styles.imageContainer}>
        {image ? (
          <img
            src={image.preview}
            alt="Uploaded Preview"
            className={styles.uploadedImage}
          />
        ) : (
          <div className={styles.uploadWrapper}>
            <button
              type="button"
              className={styles.uploadButton}
              id="optional"
              onClick={() => fileInputRef.current.click()}
            >
              이미지 업로드
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              style={{ display: "none" }}
              onChange={handleImageUpload}
            />
          </div>
        )}
        <div className={styles.likeContainer}>
          <span
            onClick={toggleLike}
            className={liked ? styles.liked : styles.unliked}
            aria-label={liked ? "Unlike" : "Like"}
          >
            <i
              className={`fa ${liked ? "fa-heart" : "fa-heart-o"}`}
              aria-hidden="true"
            ></i>
          </span>
        </div>
      </div>
    </div>
  );
}

export default UploadImage;
