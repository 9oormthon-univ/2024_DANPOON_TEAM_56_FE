import React from "react";
import styles from "./Home.module.css";
import MenuButton from "../menu/MenuButton";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCamera } from "@fortawesome/free-solid-svg-icons";
import NavBar from "../NavBar/NavBar";

function Home() {
    const navigate = useNavigate();

    return (
        <div className={styles.frame}>

            <div className={styles.menuGrid}>
                <MenuButton
                    name="Today's Mission"
                    className={`${styles.mission_button}`}
                    onClick={() => navigate('/missionroadmap')}
                />
                <MenuButton
                    name="Mission Check"
                    icon={<FontAwesomeIcon icon={faCamera} style={{ color: "#fcfcfc" }} />}
                    className={`${styles.mission_check_button}`}
                />
                <MenuButton
                    name="MY Page"
                    className={`${styles.my_page_button}`}
                />
                <MenuButton
                    name="Community"
                    className={`${styles.community_button}`}
                />
            </div>
            <NavBar />
        </div>
    );
}

export default Home;
